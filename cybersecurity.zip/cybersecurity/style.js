
        function calculateScore() {
            let totalScore = 0;
            let answeredQuestions = 0;

            for (let i = 1; i <= 5; i++) {
                const selected = document.querySelector(`input[name="q${i}"]:checked`);
                if (selected) {
                    totalScore += parseInt(selected.value);
                    answeredQuestions++;
                }
            }

            if (answeredQuestions < 5) {
                alert('Please answer all questions before getting your results.');
                return;
            }

            const percentage = Math.round((totalScore / 15) * 100);
            const resultsDiv = document.getElementById('results');
            const scoreDiv = document.getElementById('score');
            const labelDiv = document.getElementById('scoreLabel');
            const recommendationDiv = document.getElementById('recommendation');

            scoreDiv.textContent = percentage + '%';
            resultsDiv.classList.add('show');

            if (percentage >= 80) {
                labelDiv.textContent = 'Excellent Security Habits!';
                recommendationDiv.innerHTML = '<strong>Great job!</strong> You have strong cybersecurity practices. Continue staying updated with the latest security trends and maintain these good habits.';
                resultsDiv.style.background = 'linear-gradient(135deg, #4caf50 0%, #45a049 100%)';
            } else if (percentage >= 60) {
                labelDiv.textContent = 'Good, but Room for Improvement';
                recommendationDiv.innerHTML = '<strong>You\'re on the right track!</strong> Focus on implementing two-factor authentication and regular password updates to strengthen your security.';
                resultsDiv.style.background = 'linear-gradient(135deg, #ff9800 0%, #f57c00 100%)';
            } else {
                labelDiv.textContent = 'Needs Significant Improvement';
                recommendationDiv.innerHTML = '<strong>Important:</strong> Your current practices put you at risk. Start by using unique passwords, enabling 2FA, and being more cautious with emails and public Wi-Fi.';
                resultsDiv.style.background = 'linear-gradient(135deg, #f44336 0%, #d32f2f 100%)';
            }

            resultsDiv.scrollIntoView({ behavior: 'smooth' });
        }

        // Simple smooth scrolling for navigation
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
